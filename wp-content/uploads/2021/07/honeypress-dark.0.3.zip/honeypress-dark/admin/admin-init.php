<?php
if(is_admin()){
	require get_stylesheet_directory() . '/admin/inc/class-spicethemes-about-page.php';
}

require get_stylesheet_directory() . '/admin/inc/plugin-include-control.php';
require get_stylesheet_directory() . '/admin/inc/include-companion.php';


